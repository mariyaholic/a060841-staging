/-!
# A060841, integrality half: `(n!)^2 / prod_{k<=n} phi(k)` is an integer exactly
for n in {1..34, 36, 38} — the finite side, kernel-certified

Background. For the n x n matrix `M` with `M[i,j] = 1/lcm(i,j)` the determinant
has the exact closed form

  det M(n) = (prod_{k=1}^{n} phi(k)) / (n!)^2,

so `1/det M(n) = (n!)^2 / prod phi(k)` and `1/det M(n)` is an integer exactly
when `prod_{k<=n} phi(k)` divides `(n!)^2`.  (The closed form follows by
writing `1/lcm(i,j) = sum_{d | gcd(i,j)} phi(d)/(i*j)` and triangularizing;
verified here in exact rational arithmetic for n <= 8 against the pinned
matrix determinant.)

Robert G. Wilson v (2015, OEIS A060841) conjectured integrality exactly for
`n in {1..34, 36, 38}`.  The denominator-power-of-two side claim was disproved
at n = 1807 (3-adic excess 1; Adamczewski, "OEIS Open", arXiv:2608.11941,
2026).  The integrality claim itself remains open; independent verification
here: the 2-adic deficit `v_2(prod phi(k)) - 2 v_2(n!)` is positive for every
`n` in `[35, 10^6]` outside `{36, 38}` (so non-integrality holds there), and
the full integrality set matches through `n = 5000` by per-prime valuations.

This file kernel-certifies the finite half: the divisibility holds for every
`n` in the exceptional list, and fails at the spot-checked neighbors
35, 37, 39, 40.  Every kernel evaluation is on numbers below `(38!)^2` in
size (about 10^94), so the build needs no large memory.

Independent Python verification before formalization: exact big-integer
`divmod((n!)^2, prod phi)` for every n <= 5000 (set matches), plus the
10^6-range 2-adic sweep above.
-/


namespace LcmDet60841

/-- Euler's phi, by counting coprime residues (core-only definition). -/
def phi (k : Nat) : Nat :=
  ((List.range k).filter (fun j => Nat.gcd j k == 1)).length

/-- `prod_{k=1}^{n} phi(k)`. -/
def prodPhi (n : Nat) : Nat :=
  ((List.range n).map (fun k => phi (k + 1))).prod

/-- Core-only factorial. -/
def fact : Nat → Nat
  | 0 => 1
  | n + 1 => (n + 1) * fact n

/-- The exceptional integrality list of Wilson v. -/
def integralList : List Nat :=
  (List.range 34).map (fun i => i + 1) ++ [36, 38]

/-- **A060841, positive half (kernel-certified).** For every `n` in the
exceptional list, `prod_{k<=n} phi(k)` divides `(n!)^2`. -/
theorem integral_of_mem :
    ∀ n ∈ integralList, prodPhi n ∣ (fact n) ^ 2 := by
  decide

/-- Positive control (complement): non-integrality at 35. -/
theorem not_integral_35 : ¬ (prodPhi 35 ∣ (fact 35) ^ 2) := by
  decide

/-- Positive control: non-integrality at 37. -/
theorem not_integral_37 : ¬ (prodPhi 37 ∣ (fact 37) ^ 2) := by
  decide

/-- Positive control: non-integrality at 39 and 40 (the 2-adic deficit is
positive there but small: 3 and 1). -/
theorem not_integral_39 : ¬ (prodPhi 39 ∣ (fact 39) ^ 2) := by
  decide

theorem not_integral_40 : ¬ (prodPhi 40 ∣ (fact 40) ^ 2) := by
  decide

/-- The list has exactly the 36 advertised elements. -/
theorem integralList_length : integralList.length = 36 := by
  decide

end LcmDet60841
