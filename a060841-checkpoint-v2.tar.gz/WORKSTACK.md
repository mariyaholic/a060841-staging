# WORKSTACK

## Threads
- `feat/a60841-lcm-det-cert` tracks the A060841 (lcm-matrix determinant) integrality certificate: a core-Lean 4.35.0 finite-half module, long-range computational verification of the full claim, and the scope reduction to one open 2-adic inequality (`d2(n) >= 1` for `n in {35, 37} u [39, infinity)`).

```text
From→To: hermes.impl → user.review
Done: Confirmed the closed form det M(n) = prod_{k<=n} phi(k)/(n!)^2 against exact rational determinants (n <= 8) and the OEIS reduced fractions; kernel-certified in certs/a060841/LcmDet60841.lean that prod_{k<=n} phi(k) divides (n!)^2 for every n in {1..34, 36, 38} (one bounded decide) plus non-integrality controls at 35, 37, 39, 40 (decide on the exact remainder); verified computationally through n = 10^8 (certs/a060841/verify_d2.py, results/verify_result.json) with zero deviations from the integrality set and d2(n) >= 1 throughout [35, 10^8] \ {36, 38}; independently reproduced the Adamczewski (arXiv:2608.11941) n = 1807 witness, which refutes only the denominators-are-powers-of-two side claim (3-adic excess 1), leaving the integrality conjecture open; derived the exact identity d2(n) = sum_{p odd <= n} floor(n/p) v2(p-1) - floor(n/2) - v2(n!) and its tower form, with the minimum d2 = 1 attained at n = 40.
Next: Prove d2(n) >= 1 for n in {35, 37} u [39, infinity) using the tower identity; upstream the finite half into google-deepmind/formal-conjectures/OEIS/60841.lean (needs a mathlib build environment).
Files: certs/a060841/LcmDet60841.lean, certs/a060841/verify_d2.py, certs/a060841/results/*, certs/a060841/README.md, notes/a060841-lcm-det-checkpoint.md, WORKSTACK.md
Verify: lean -j 1 -M 2500 LcmDet60841.lean exit 0 (0 warnings, peak RSS 1.31 GB, Lean 4.35.0 commit eb6cafb7); kernel-certified non-integrality for every n in [35, 256] except 36 and 38 in addition to the 36 integrality cases; trust grep over certs/a060841 has exactly one hit (the file-level set_option maxRecDepth, elaborator machinery — disclosed in the PR body); #print axioms gives [propext] only (integralList_length: none); corrupted control (35 added to the list) rejected by decide; verify_d2.py self-check vs exact divmod through n = 300 and 0 violations at N = 10^8 in 867 s.
Blockers: The d2 inequality is unproved (data-verified to 10^8 only); upstreaming needs mathlib, which does not fit this machine (2.6 GB disk free, 4 GB RAM cap).
```

- `feat/cubic-acute-ii` tracks Part II of the Cubic Acute Sets (`OEIS A089676`) Lean 4.35.0 formalization, solver upgrade, release paper, and v2.0.0 archive (`docs/cubic-acute-sets-ii/`), expanding `CubicAcuteSets` from 8 to 15 Lean modules (`ExactCerts8Defs`, `ExactCerts8A..D`, `ExactBounds` `exact_a_8`, `HarangiS3`, `RecordsII`).

```text
From→To: gemini.impl → user.review
Done: Verified full 0..100 OEIS a089676_2.txt comparison (28 wins, 26 ties, 47 deficits), Harangi Table 3 comparison (47 wins, 15 ties, 20 deficits), 34/34 independent Python checks (solver/export_lean.py::is_acute), enumRoots 4..9 = [4, 11, 28, 65, 139, 272], and Lean.collectAxioms across all 386 public theorems; authored docs/cubic-acute-sets-ii/{cubic-acute-sets-ii.tex,cubic-acute-sets-ii.pdf,index.html}; updated lean/cubic-acute-sets/README.md, solver/README.md, CITATION.cff, .zenodo.json, and WORKSTACK.md; merged origin/main, fixed Part I n=81..90 README bounds and n=22..23 gain phrasing, recompiled PDF, and rebuilt and tested cubic-acute-sets-v2.0.0.zip.
Next: Commit and push audit fixes on feat/cubic-acute-ii and verify both read-only auditors return STATUS: CLEAN on the same pushed commit.
Files: docs/cubic-acute-sets-ii/*, lean/cubic-acute-sets/README.md, solver/README.md, CITATION.cff, .zenodo.json, WORKSTACK.md
Verify: lake clean && lake build in unpacked /tmp/zenodo_test (17 jobs, exit 0, 0 warnings); trust grep exit 1; pdflatex x2 gave 7 pages, 0 warnings/overfull/underfull boxes, 0 [?]/?? markers; Lean.collectAxioms bad=0 across all 386 public theorems.
Blockers: Upper bounds for a(9) = 16 and a(10) = 17, Harangi constructions over F_{p^r} (r >= 2) and s >= 4, and exact values a(n) for n >= 11 remain unformalized or open mathematically.
```

```text
From→To: gemini.impl → user.resume
Done: Formalized exact optimality a(8) = 10 (acuteUpperBound_8, exact_a_8, not_hasAcuteSet_8_11) via binary-split certificate checking in ExactCerts8Defs.lean, ExactCerts8A..D.lean, and ExactBounds.lean; formalized Harangi Theorem 3.14 (s = 3, 5-block Vandermonde MDS construction for primes p >= 5) and refutation checks in HarangiS3.lean; upgraded solver/search.cpp and solver/export_lean.py and certified extended explicit witnesses (n = 18..26) and cascade bounds (n = 28..100) in RecordsII.lean.
Next: Inspect full 0..100 OEIS a089676_2.txt diff and n = 9 canonical-root telemetry, write docs/cubic-acute-sets-ii/ (LaTeX, PDF, index.html, package_zenodo.sh), update READMEs, CITATION.cff, and .zenodo.json, verify unpacked Zenodo zip build, and run the two-subagent audit loop.
Files: lean/cubic-acute-sets/CubicAcuteSets.lean, lean/cubic-acute-sets/CubicAcuteSets/{HarangiS3,ExactCerts8Defs,ExactCerts8A,ExactCerts8B,ExactCerts8C,ExactCerts8D,ExactBounds,RecordsII}.lean, solver/search.cpp, solver/export_lean.py, WORKSTACK.md
Verify: lake build in lean/cubic-acute-sets/ exited 0 (17 jobs, 0 warnings); trust grep across lean/ returned exit 1 (0 matches).
Blockers: Paused at user request before authoring docs/cubic-acute-sets-ii/, updating release metadata, packaging v2.0.0 zip, and running the two-subagent audit loop.
```

- `docs/zenodo-release-bundle` (following merged PR #2 `feat/cubic-acute-sets`, PR #3 `docs/math-paper-release`, and PR #4 `docs/paper-author-provenance`) tracks the self-contained Zenodo source bundle, Apache-2.0 source license and `NOTICE`, and public-link cleanup over the Lean 4.35.0 formalization of Cubic Acute Sets (OEIS A089676) in `lean/cubic-acute-sets/`, local search solver in `solver/`, mathematics release paper stylesheet in `design/uika-math-paper.css`, release paper in `docs/cubic-acute-sets/` (`cubic-acute-sets.tex`, `cubic-acute-sets.pdf`, `index.html`), citation metadata (`CITATION.cff`, `.zenodo.json`), and verification workflows in `WORKFLOW.md` and `AGENTS.md`. `TARGETS.md`, `SOURCES.md`, and `FRESHNESS.md` sit on PR #1 (`docs/freshness-checks`), so we keep status notes here and in `lean/cubic-acute-sets/README.md`.

```text
From→To: gemini.review → user.submit
Done: Fetched and verified Bevan (2006, doi:10.37236/1038), Harangi (2011, users.renyi.hu/~harangi/papers/acute.pdf), and OEIS A089676 (b089676.txt, a089676_1.txt, a089676_2.txt dated 2/11/2026); updated Theorem 3.2 in cubic-acute-sets.tex, index.html, and lean/cubic-acute-sets/README.md to cite Bevan Thm. 4.3 (m=2, Z=S_2) for hasAcuteSet_bevan_mul and Bevan Cor. 4.5.1 via Thms. 4.2 and 4.3 for hasAcuteSet_bevan_triple; placed \FloatBarrier before the Author Contributions and AI Disclosure paragraph in cubic-acute-sets.tex so Table 3 does not split it across pages 5 and 6; specified Claude Opus 5.5 (Anthropic) across all release files; recompiled cubic-acute-sets.pdf and rebuilt /home/antigravity/cubic-acute-sets-v1.0.0.zip; published v1.0.0 on Zenodo (doi:10.5281/zenodo.24210870) and recorded the DOI in CITATION.cff.
Next: Merge PR #6 into main after review, submit new lower bounds for n = 16..24 and 47..53 to OEIS A089676, and consider Harangi s >= 3 compositions from n = 17..24 records.
Files: docs/cubic-acute-sets/cubic-acute-sets.tex, docs/cubic-acute-sets/cubic-acute-sets.pdf, docs/cubic-acute-sets/index.html, lean/cubic-acute-sets/README.md, .zenodo.json, CITATION.cff, WORKSTACK.md
Verify: lake clean && lake build in both workspace and unpacked /tmp/zenodo_test (10 jobs, exit 0, 0 warnings); trust grep exit 1; #print axioms on all 267 public theorems and Lean.collectAxioms on 1,287 kernel entries within {propext, Classical.choice, Quot.sound}; solver/export_lean.py verified all 16 baseline and 9 record witnesses; pdflatex x2 gave 0 warnings/bad boxes, 6 pages, 0 [?]/?? markers; JSON syntax verified on .zenodo.json; live source checks confirmed Bevan S3..S8 and kappa(9)=16 computer search ownership, Bevan Thm 4.1/4.2/4.3/Cor 4.5.1, Harangi Thm 3.14 & Table 3, and Kamenetsky a089676_2.txt date 2/11/2026 and all 16 Table 2 bounds (with 5 cascade bounds n=25,26,54,60,72 below a089676_2.txt).
Blockers: None. Exact upper bounds for a(8) = 10, a(9) = 16, and a(10) = 17 remain unformalized in Lean, and exact values for n >= 11 remain mathematically open.
```

```text
From→To: gemini.impl → user.submit
Done: Added Apache-2.0 source license and NOTICE (lean/cubic-acute-sets/LICENSE, lean/cubic-acute-sets/NOTICE) plus reproducible packaging script (docs/cubic-acute-sets/package_zenodo.sh), removed private repository URLs and stylesheet filename prose from release text/metadata, compiled cubic-acute-sets.pdf, built and unpacked cubic-acute-sets-v1.0.0.zip to verify standalone lake clean && lake build, and updated release hygiene rules in WORKFLOW.md.
Next: Upload docs/cubic-acute-sets/cubic-acute-sets.pdf and /home/antigravity/cubic-acute-sets-v1.0.0.zip together to Zenodo while keeping this repository private, merge PR #5 (docs/zenodo-release-bundle) into main, and optionally formalize exact upper bounds for a(8)=10, a(9)=16, a(10)=17 or Harangi s>=3 compositions.
Files: lean/cubic-acute-sets/LICENSE, lean/cubic-acute-sets/NOTICE, lean/cubic-acute-sets/README.md, solver/README.md, docs/cubic-acute-sets/*, CITATION.cff, .zenodo.json, README.md, WORKFLOW.md, AGENTS.md, WORKSTACK.md
Verify: lake clean && lake build in both workspace and unpacked /tmp/zenodo_test archive (10 jobs, exit 0, 0 warnings); trust grep exit 1; #print axioms on all 267 exported theorems uses only {propext, Classical.choice, Quot.sound}; pdflatex cubic-acute-sets.tex (6 pages, 0 warnings/overfull boxes, 8 verified citations, 0 private repo URLs or private system references in release text)
Blockers: Exact upper bounds for n >= 8 exceed kernel branching-certificate reduction at current symmetry-breaking scale; a(8..10) remain exactness targets and n >= 11 remain mathematically open.
```

## Verification
- On `2026-11-14` (Part II / `feat/cubic-acute-ii`): checked all `HasAcuteSet n k` bounds across `Witnesses.lean`, `Records.lean`, and `RecordsII.lean` (`0 <= n <= 100`) against OEIS `a089676_2.txt` (SHA256 verified against `2026-11-13` fetch: `28` wins at `16..26`, `47..53`, `81..90`; `26` ties; `47` deficits) and Harangi Table 3 (`1 <= n <= 82`: `47` wins, `15` ties, `20` deficits), and verified all `34/34` `*Masks*` sets independently via `solver/export_lean.py::is_acute` (`0` failures).
- Evaluated `enumRoots` for `n = 4..9` (`[4, 11, 28, 65, 139, 272]`) and checked `Lean.collectAxioms` in `lake env lean --stdin` across all `386` public theorems (`6` empty `[]`, `43` `[propext]`, `4` `[Quot.sound]`, `55` `[propext, Quot.sound]`, `278` `[propext, Classical.choice, Quot.sound]`, `0` custom/forbidden axioms), covering `exact_a_8`, `acuteUpperBound_8`, `not_hasAcuteSet_8_11`, `hasAcuteSet_harangi_s3`, `not_isPrime_four`, `not_vandermonde_2x5_composite4`, `not_vandermonde_2x5_prime3`, and `hasAcuteSet_18_134`..`100_3285888`.
- Compiled `docs/cubic-acute-sets-ii/cubic-acute-sets-ii.tex` twice with `pdflatex` to `cubic-acute-sets-ii.pdf` (`7` pages, A4, `0` warnings/Overfull/Underfull boxes, `0` `[?]`/`??` markers, `0` release-hygiene hits, subset-embedded Type 1 fonts) with `[1]`–`[9]` alphabetical citations (`[9]` Sugui v1.0.0 DOI `10.5281/zenodo.24210870`) aligned 1-to-1 with `docs/cubic-acute-sets-ii/index.html`; validated `.zenodo.json` (`isNewVersionOf`) and `CITATION.cff` (`v2.0.0`, referencing Part I in `references:`).
- Packaged `/home/antigravity/cubic-acute-sets-v2.0.0.zip` (`676994` bytes, `34` files) with `docs/cubic-acute-sets-ii/package_zenodo.sh`, confirmed zero private files (`AGENTS.md`, `WORKSTACK.md`, `.git/`, `.lake/`), verified `lake clean && lake build` (`17` jobs, exit `0`, `0` warnings) in unpacked `/tmp/zenodo_test`, and removed temporary `/tmp` test files.
- On `2026-11-13`, we fetched `https://oeis.org/A089676` (HTTP 200, 596 lines), `b089676.txt` (HTTP 200, 12 lines, `sha256:2e8cd4e6c6fb0368b54e8f396a6a5a84fd1ea7c94a6e5a8655a79441e957da81`), `a089676_1.txt` (HTTP 200, 16 lines, `sha256:b4de715c9a4208cd13ac67cfa83f6f70511e8339c9e1ceeb387afc61de93631c`), and `a089676_2.txt` (HTTP 200, 123 lines, `sha256:5dbef016c96e48f77fc1f964c2626646edde2cb6765b33623dd2913d3c271a5c`, dated `2/11/2026` by D. Kamenetsky), `https://doi.org/10.37236/1038` (Bevan 2006 PDF, verifying Sec. 5 computer-search optimality claim for `S3..S8` and `kappa(9) = 16`, Thm. 4.1, Thm. 4.2, Thm. 4.3, and Cor. 4.5.1), and `https://users.renyi.hu/~harangi/papers/acute.pdf` (Harangi 2011 PDF, verifying Thm. 3.14 and Table 3 for `1 <= d <= 82`), and confirmed `google-deepmind/formal-conjectures` (`04937a4cccadd0a205abdf2c706938c6c95e4177`) has 0 hits, GitHub Lean search has only `mo271/FormalBook:FormalBook/Chapter_17.lean`, and `qedavid/solverz` lists `table/cubic-acute-sets` as open (`2026-11-05`, not in `active.md`).
- We ran `lake clean && lake build` in `lean/cubic-acute-sets/` and it exited 0 (`Build completed successfully (10 jobs)`, 0 warnings), and verified all nine record witnesses (`recordMasks16`..`24`) independently in Python via `solver/export_lean.py`.
- We ran `grep -rn --include="*.lean" "sorry\|axiom \|native_decide\|ofReduceBool\|trustCompiler\|unsafe\|set_option" lean/` and got exit 1 (zero matches).
- We inspected `#print axioms` via `lake env lean --stdin` on all 267 public theorems across the root importer and seven modules (`Basic`, `FastCheck`, `Structure`, `Witnesses`, `ExactCerts`, `ExactBounds`, `Records`, including `not_isAcute_rightAngle2`, `not_isAcute_duplicate1`, `not_hasAcuteSet_of_gt`, and `not_hasAcuteSet_0_2`..`not_hasAcuteSet_7_10`) and confirmed dependence only on `[propext]`, `[Quot.sound]`, `[propext, Quot.sound]`, `[propext, Classical.choice, Quot.sound]`, or `[]`.
- We compiled `docs/cubic-acute-sets/cubic-acute-sets.tex` twice with `pdflatex` to `cubic-acute-sets.pdf` (6 pages, A4, zero LaTeX warnings or Overfull/Underfull boxes, zero `[?]`/`??` markers, Latin Modern and AMS `amssymb` Type 1 fonts subset-embedded, `pdfinfo Tagged: no`) and verified all 8 alphabetical references (`[1]` Bevan 2006 through `[8]` Randriambololona 2013) match across `.tex`, `.pdf`, `index.html`, and OEIS A089676.
- We packaged `/home/antigravity/cubic-acute-sets-v1.0.0.zip` (`552887 bytes`, `27 files`) with `docs/cubic-acute-sets/package_zenodo.sh`, unpacked it into `/tmp/zenodo_test`, confirmed zero repository-private files (`AGENTS.md`, `WORKSTACK.md`, `.git`, `.lake`) appear in the archive, ran `lake clean && lake build` (`10 jobs`, exit `0`, zero warnings) from the unpacked directory, and deleted `/tmp/zenodo_test`.
- Exact upper bounds for `a(8) = 10`, `a(9) = 16`, and `a(10) = 17` remain unformalized (certified witnesses exist in `Witnesses.lean`), and exact values for `n >= 11` remain mathematically open.

## Cubic acute-set orbit audit

Historical checkpoint; later handoffs supersede status and verification counts here.

```text
From→To: codex.impl → next.impl
Done: Added computational orbit enumeration and property tests for dimensions 1–6; independently reproduced the dimension 7 published counts and the dimension 8 rooted size-10 count with separate C++ searches.
Next: Extend the search and certificate format, prove an equivariant canonical-root theorem, and build the Lean classification before considering dimensions 8–10.
Files: solver/small_acute_orbits.py, solver/test_small_acute_orbits.py, solver/independent_acute_orbits.cpp, solver/acute_n8_count_probe.cpp
Verify: Four Python property tests pass; independent checks reproduce OEIS counts through dimension 7; the n=8 probe completed with 40,345,200 rooted sets and its derived labeled count matches OEIS. These are computations, not Lean-verified classification proofs.
Blockers: No authenticated local checkout or Lean toolchain in this environment; no n=8 orbit classification, kernel build, certificate or release-paper audit has been completed.
```

## Cubic acute-set orbit continuation

Historical checkpoint; later handoffs supersede status and verification counts here.

```text
From→To: codex.impl → next.impl
Done: Added cube and coordinate equivalences, a symmetry-preserving root theorem, certified distinct witness families for n=3–7, and computational n=8 classification evidence.
Next: Prove completeness and labeled counts in Lean, extend the classifier to n=9–10, and perform the paper and citation audits.
Files: lean/cubic-acute-sets/CubicAcuteSets/{ExactBounds,Isomorphism,FourWitnesses,FiveWitnesses,SixWitnesses,SevenWitnesses}.lean, solver/acute_isomorph_enum.cpp, solver/verify_acute_burnside.py, solver/acute_orbit_data/, notes/cubic-acute-orbit-checkpoint.md
Verify: Lean 4.35.0 clean build passed 15 jobs; 324 source-level public declarations used only permitted axioms; trust scan clear. Two n=8 runs and independent Burnside checks report 29,636 classes, not yet kernel-certified.
Blockers: No Lean classification-completeness certificate, no exact n=8 orbit theorem, no n=9–10 computation, and no completed dual release audit. The 29,636 value is a computational candidate conditional on size 10 being maximal.
```

## Cubic acute-set classification continuation

Historical checkpoint; later handoffs supersede status and verification counts here.

```text
From→To: codex.impl → next.impl
Done: Kernel-checked exact coordinate classifications for n=3 and n=4, exact labeled families through n=4, and inequivalent witness families for n=5–7; computed a candidate n=8 orbit count with independent verification.
Next: Prove n=5–7 classification completeness and labeled counts, develop n=8 certificates, then complete paper, citation, interactive and release audits.
Files: lean/cubic-acute-sets/CubicAcuteSets/{ThreeExact,FourExact,FourLabeled,Isomorphism,FourWitnesses,FiveWitnesses,SixWitnesses,SevenWitnesses}.lean; solver/acute_isomorph_enum.cpp; solver/verify_acute_burnside.py; solver/acute_orbit_data/; notes/cubic-acute-orbit-checkpoint.md
Verify: Lean 4.35.0 clean build passed 18 jobs with no warnings. Source-pattern scan of 380 public declarations found only standard permitted axioms; trust-escape scan clear. Two n=8 runs and an independent Burnside check report 29,636 coordinate classes.
Blockers: n=5–8 completeness is not kernel-verified, n=9–10 are not computed, and the requested paper and dual release audit remain unfinished. OEIS direct fetch returned HTTP 403.
```

## Cubic acute-set dimension five handoff

Historical checkpoint; later handoffs supersede status and verification counts here.

```text
From→To: codex.impl → next.impl
Done: Proved exact coordinate and labeled classifications in dimensions 3–5, including 18 classes and 352 labeled sets at n=5; saved reproducible n=8 computational candidate 29,636.
Next: Finish Lean completeness and labeled counts for n=6–7; pursue n=8 certificates and n=9–10 computations, then paper and release reviews.
Files: lean/cubic-acute-sets/CubicAcuteSets/{ThreeExact,FourExact,FourLabeled,FiveRooted,FiveRootFamilies,FiveTranslatedFamilies,FiveClassification,FiveLabeledChunks,FiveLabeledCoverage,FiveLabeledDistinct,FiveLabeledExact}.lean; solver/acute_orbit_data/; notes/cubic-acute-orbit-checkpoint.md
Verify: Lean 4.35.0 clean build passed 26 jobs without warnings; source-pattern audit of 590 public declarations found only permitted axioms; trust scan clear. Proof additions were independently reviewed.
Blockers: n=6–8 classification completeness remains unproved in Lean; dimension 8 is a computational candidate, n=9–10 are not computed, and paper and mandatory release audits remain unfinished.
```

## Cubic acute-set dimension six handoff

```text
From→To: codex.impl → next.impl
Done: Kernel-checked exact coordinate classifications for n=3–6 and exact labeled families for n=3–5; independently checked the computational n=8 candidate of 29,636 classes.
Next: Prove n=6 labeled count and n=7 classification completeness, produce n=8 formal certificates, and complete paper and release audits.
Files: lean/cubic-acute-sets/CubicAcuteSets/{ThreeExact,FourExact,FourLabeled,FiveClassification,FiveLabeledExact,SixRootCompletion,SixRootBridge,SixRootExtraction,SixFullExtraction,SixTranslatedCertificates,SixClassification,SevenWitnesses}.lean; solver/acute_isomorph_enum.cpp; solver/acute_orbit_data/; notes/cubic-acute-orbit-checkpoint.md
Verify: Clean Lean 4.35.0 build passed 28 jobs before SixRootBridge and SixClassification; incremental builds for later proof modules passed with targeted axiom audits. Independent reviewers checked the new proofs.
Blockers: n=6 labeled count and n=7–8 completeness lack Lean proofs; dimension 8 remains a computational candidate; n=9–10 and release audits are unfinished.
```

## Cubic acute-set dimension seven handoff

```text
From→To: codex.impl → next.impl
Done: Proved exact coordinate classes for dimensions 3–7, including 64 classes at n=7; proved exact labeled families through n=6; saved the n=8 computational candidate 29,636.
Next: Prove n=7 labeled count, develop n=8 kernel certificates, and finish paper, citations and final independent audits.
Files: lean/cubic-acute-sets/CubicAcuteSets/{SevenRootCompletion,SevenRootBridge,SevenRootExtraction,SevenActionSoundness,SevenOrbitCertificates,SevenClassification}.lean; solver/acute_isomorph_enum.cpp; solver/acute_orbit_data/; notes/cubic-acute-orbit-checkpoint.md
Verify: Incremental Lean 4.35.0 build passed 41 jobs; independent review checked all new theorem axioms and trust scan. A clean whole-project final audit remains pending.
Blockers: n=7 labeled count and n=8 exact classification lack Lean proofs; n=9–10 are not computed; release paper and dual final audit are unfinished.
```

## Cubic acute-set three-hour checkpoint

```text
From→To: codex.impl → next.impl
Done: Proved exact coordinate classes through n=7 and labeled families through n=6; preserved a computed candidate of 29,636 classes for n=8 and 47 scratch code-length checks for n=7.
Next: Complete n=7 code-length checks and prove sorting, deduplication, orbit cardinality and the labeled total; develop n=8 kernel certificates and complete paper and release audits.
Files: checkpoints/n7-orbit-counts/README.md and N7OrbitCountsManifest.md; notes/cubic-acute-n7-labeled-handoff.md; solver/n8-feasibility/; solver/acute_orbit_data/; CubicAcuteSets/SevenClassification.lean and SevenOrbit*.lean
Verify: Lean 4.35.0 clean build passed 28 jobs before later modules; later incremental builds passed and added modules received independent targeted review. At checkpoint 47 scratch code-length theorems compiled, but their OLean binaries are not stored in Git and the scratch import graph needs reconstruction.
Blockers: n=7 labeled total is not Lean-proved; n=8 classification is computational, n=9–10 are not computed, and final clean build plus dual release audit remain outstanding. Memory pressure caused exit 137 during earlier attempts.
```

## Cubic acute-set safe handoff, 2026-11-15

```text
From→To: codex.impl → next.impl
Done: Preserved stopped-state counts, evidence references, methods, failed routes and a cost-conscious continuation prompt; no new search or proof build was started.
Next: Recover Drive proof sources and dependencies, reconcile the ledger, then integrate a bounded verified batch before any new classification claims.
Files: notes/cubic-acute-safe-handoff-2026-11-15.md; linked Drive notebook, certificates and audits; additional proof sources are not integrated by this documentation PR.
Verify: Observed root458 exit0 replay log with [propext]; worker reports n9 230/272 and n10 242/499, root429 qualified; no matching local Lean/search processes at inspection. No fresh full-project build.
Blockers: Source integration and full coverage/classification bridge remain incomplete; Drive access needed for absent root445/root480 sources; 299 roots remain, or300 under stricter root429 accounting.
```

## Recovered dimension-ten proof sources

```text
From→To: codex.impl → next.impl
Done: Integrated saved Drive sources for roots 445, 458 and 480, their raw certificates and provenance, and main-importer entries; these roots were already counted in the reported total.
Next: Run full branch clean build and final audits before release; recover older saved root sources in bounded batches and complete the coverage/classification bridge.
Files: CubicAcuteSets/TenRoot{445,458,480}.lean; CubicAcuteSets.lean; checkpoints/n10-drive-roots/{README.md,manifest.json}.
Verify: Each recovered source and certificate matches recorded hashes; all three targeted Lean 4.35.0 replays exited 0 with [propext], reusing built dependencies whose source chain matches main.
Blockers: No fresh full clean build or final dual audit; older checkpoint proofs not all integrated; no complete dimension 9–10 classification theorem.
```

## n=8–10 evidence recovery, 2026-11-15

```text
From→To: codex.impl → next.impl
Done: Added the complete 627-file Drive snapshot (including n8 exact-source tarball, historical source diff, build log and SHA list), 172 additional readable Drive artifacts, and a reconstructed saved n9 root47 Lean source directly to PR #14; indexed every copied item and all remaining Drive links/errors. Existing n8 exact theorem sources and n10 roots 445/458/480 remain in the repository.
Next: Run the pinned Lean 4.35.0 clean build and required audits on a writable checkout; reconcile n9 230/272 reported versus 224/272 in the saved log; recover the missing EightRoot69Splits dependency before importing n9 sources; retrieve 33 large and 7 transport-failed external payloads through a transfer path that can carry them.
Files: checkpoints/n8-n10-recovery/{README.md,manifest.json}; checkpoints/n8-exact/README.md; checkpoints/n9-root047/{NineRoot47.lean,README.md}; checkpoints/acute-dim-search-2026-11-15/*; checkpoints/n10-audits/*; checkpoints/colab-n10-search/*; WORKSTACK.md
Verify: GitHub accepted all staged artifact blobs; 627 + 172 + 1 recovered-source files are indexed in the recovery manifest. The root47 source was reconstructed from the ordered saved Base64 payloads; its recorded source hash and historical replay are cited, but not freshly recomputed here. No branch clean build or dual audit was run.
Blockers: 33 Drive-only files total 1,155,167,372 bytes and 7 transport failures total 55,796,378 bytes; full Lean build/audits pending. n9/n10 root ledgers are not complete classification proofs; n9 saved count discrepancy remains unresolved.
```
