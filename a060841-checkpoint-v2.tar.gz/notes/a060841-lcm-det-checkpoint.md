# A060841 checkpoint: lcm-matrix determinant integrality

Date: 2026-11-15. Handle: hermes.impl. Branch: feat/a60841-lcm-det-cert.

## Statement

OEIS A060841 tracks `num(1/det M_n)` for the n x n matrix `M[i,j] = 1/lcm(i,j)`.
Robert G. Wilson v (2015) conjectured that `1/det M_n` is an integer exactly for
`n in {1..34} u {36, 38}`. The formal statement lives upstream in
google-deepmind/formal-conjectures (`FormalConjectures/OEIS/60841.lean`,
`conjecture1`, still tagged `research open`).

## What this branch adds

1. `certs/a060841/LcmDet60841.lean` — a core-Lean 4.35.0 module (no mathlib, no
   imports) kernel-certifying the finite half: `prod_{k<=n} phi(k)` divides
   `(n!)^2` for every n in the exceptional list (one bounded `decide`), plus
   kernel-certified non-integrality at n = 35, 37, 39, 40 as controls.
   Key fact: `det M(n) = (prod_{k<=n} phi(k)) / (n!)^2`, so integrality is the
   divisibility above. The closed form was checked against exact rational
   determinants for n <= 8 and against the reduced fractions in the OEIS
   entry (1, 4, 18, 144, 900).
2. `certs/a060841/verify_d2.py` — incremental p-adic verification of the full
   claim over a long range (results below; a computation, not a Lean proof).
3. `certs/a060841/results/` — the verification outputs with the run log.

## Scope reduction (the mathematical content)

Writing `d2(n) = v_2(prod_{k<=n} phi(k)) - 2 v_2(n!)`, the conjecture reduces
to the single inequality `d2(n) >= 1` for `n in {35, 37} u [39, infinity)` plus
36 finite kernel checks. Exact identity used for the analysis:

```
d2(n) = sum_{p odd <= n} floor(n/p) * v2(p-1) - floor(n/2) - v2(n!)
      = sum_{m odd <= n} (t+1) * (c(m) - (t+2)/2),  t = floor(log2(n/m)),
        c(m) = sum_{p | m} v2(p-1)
```

Data: the minimum of `d2(n)` for n >= 35 is 1 (attained at n = 40), so a crude
bound cannot work; the verification and the tower identity are the groundwork
for the remaining proof.

## Relation to the 2026 "disproof"

Adamczewski (arXiv:2608.11941, appendix, $6 entry) disproved only the side
claim "the reduced denominator is always a power of two": at n = 1807 the
3-adic excess is exactly 1, so the denominator is divisible by 3. This branch
reproduces that witness independently (valuation pipeline gives 3-excess 1 at
n = 1807, and exact big-integer divmod confirms `prod phi` does not divide
`(n!)^2` there). The integrality conjecture itself is untouched by that
disproof and stays open.

## Verification summary

- Kernel: `lean -j 1 -M 2500 LcmDet60841.lean` exits 0 with no warnings;
  `#print axioms` reports `[propext]` only (`integralList_length`: none);
  a corrupted control (adding 35 to the list) is rejected by `decide`.
- Computation: through n = 10^8, zero deviations from the conjectured
  integrality set and `d2(n) >= 1` throughout `[35, 10^8] \ {36, 38}`;
  self-checked against exact big-integer divmod for n <= 300. See
  `results/verify_result.json`.

## Next work

Prove the `d2(n) >= 1` inequality for n in {35, 37} u [39, infinity). The
tower identity above is the starting point; the minimum at n = 40 (d2 = 1)
shows the proof must be sharp at small n.
