# A060841 integrality certificate — verification guide

Kernel-certified module for the finite half of the A060841 integrality
conjecture (Robert G. Wilson v, 2015), plus the long-range computational
verification of the full claim. See `notes/a060841-lcm-det-checkpoint.md`
for the full context and scope reduction.

## Contents

- `LcmDet60841.lean` — core Lean 4.35.0 module, no imports, no mathlib.
  Proves `prod_{k<=n} phi(k) | (n!)^2` for every n in the exceptional list
  `{1..34, 36, 38}` (one bounded kernel `decide`), and non-integrality at
  n = 35, 37, 39, 40 (kernel `decide` on the exact remainder).
- `verify_d2.py` — incremental p-adic verification of the full claim over
  `[1, N]`: integrality set membership and the 2-adic deficit inequality
  `d2(n) >= 1` for `n >= 35 \ {36, 38}`. Self-checked against exact
  big-integer divmod for `n <= 300`. Checkpoints every 10^6.
- `results/verify_result.json`, `results/verify_progress.log` — outputs of
  the run with `N = 10^8`.
- `results/SHA256.txt` — hashes of everything above.

## Reproduce the kernel part

Pinned toolchain: Lean 4.35.0 (leanprover/lean4 release, commit eb6cafb7).
Memory-light invocation, single process:

```sh
lean -j 1 -M 2500 LcmDet60841.lean        # exits 0, no warnings, ~2 min, <1.4 GB
lean -j 1 -M 2500 -o LcmDet60841.olean LcmDet60841.lean
LEAN_PATH=. lean -j 1 -M 2500 Check.lean  # prints #print axioms for the theorems
```

Recorded axiom output: `integral_of_mem`, `not_integral_35`, the range
theorems depend on `[propext]` only; `integralList_length` on no axioms. A
corrupted control (adding 35 to `integralList`) is rejected by `decide` in
both the divisibility theorem and the length theorem.

Trust grep (`sorry|axiom |native_decide|ofReduceBool|trustCompiler|unsafe|set_option`)
over `certs/a060841/`: exactly one hit, the file-level
`set_option maxRecDepth 1000000`. It raises the elaborator recursion
allowance for the 256-range kernel evaluations (the default depth of 512 is
exceeded by the per-element evaluations near n = 256); it is elaborator
machinery, not a trust escape — no `sorry`, `axiom`, `native_decide`,
`ofReduceBool`, `trustCompiler`, or `unsafe` appears anywhere.

## Reproduce the computational part

```sh
python3 verify_d2.py 100000000 results    # ~15 min, <2.5 GB RSS
```

## Result summary (N = 10^8)

- Zero deviations from the conjectured integrality set.
- `d2(n) >= 1` for every n in `[35, 10^8] \ {36, 38}` (zero violations).
- `d2` grows roughly like `n log log n` (28.8M at 10^7, 3.1e8 at 10^8);
  the minimum over the allowed range is 1, attained at n = 40.

## Status

Kernel-certified in this module: integrality for all 36 exceptional n, and
non-integrality for every n in `[35, 256]` except 36 and 38. The open
mathematical core is the inequality `d2(n) >= 1` for
`n in {35, 37} u [39, infinity)`, which extends non-integrality beyond 256;
everything else is either kernel-certified here or reduces to it.
Computation is evidence, not a Lean proof.
