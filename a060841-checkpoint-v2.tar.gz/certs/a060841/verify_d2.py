#!/usr/bin/env python3
"""A060841 integrality verification, memory-lean incremental p-adic bookkeeping.

State: single dict defc[q] = v_q(prod_{k<=n} phi(k)) - 2 v_q(n!).
integrality(n) <=> no q has defc[q] > 0.  d2(n) = defc[2].

Claims verified for every n in [1, N]:
  (a) integrality(n) <=> n in {1..34, 36, 38}
  (b) d2(n) >= 1 for every n >= 35, n not in {36, 38}

Self-check: n <= 300 cross-checked against exact big-integer divmod.
Checkpoint line every 10^6.  p-1 factorizations cached only for p <= 10^5.
"""
import sys, json, time, math
from array import array

N = int(sys.argv[1]) if len(sys.argv) > 1 else 100_000_000
OUT = sys.argv[2] if len(sys.argv) > 2 else "/home/node/lean-scratch/a60841/results"
t0 = time.time()

spf = array("I", range(N + 1))
for i in range(2, int(N ** 0.5) + 1):
    if spf[i] == i:
        for j in range(i * i, N + 1, i):
            if spf[j] == j:
                spf[j] = i

def factor(x):
    d = {}
    while x > 1:
        p = spf[x]
        e = 0
        while x % p == 0:
            x //= p
            e += 1
        d[p] = e
    return d

_p1cache = {}
CACHE_MAX = 100_000
def p1_factors(p):
    f = _p1cache.get(p)
    if f is None:
        f = sorted(factor(p - 1).items())
        if p <= CACHE_MAX:
            _p1cache[p] = f
    return f

defc = {}      # q -> deficit
pos = set()    # q with defc > 0
d2 = 0
SET = set(range(1, 35)) | {36, 38}
viol_set, viol_d2, bad_events = [], [], []
d2_min, d2_min_at = 10**9, -1

def touch(q):
    v = defc.get(q, 0)
    if v > 0:
        pos.add(q)
    else:
        pos.discard(q)

n = 0
def exact_integral(m):
    P = 1
    for k in range(1, m + 1):
        kk, res, f = k, k, 2
        while f * f <= kk:
            if kk % f == 0:
                res = res // f * (f - 1)
                while kk % f == 0:
                    kk //= f
            f += 1
        if kk > 1:
            res = res // kk * (kk - 1)
        P *= res
    return math.factorial(m) ** 2 % P == 0

with open(f"{OUT}/verify_progress.log", "w") as prog:
    for n in range(1, N + 1):
        for q, e in factor(n).items():
            defc[q] = defc.get(q, 0) - 2 * e
            touch(q)
            if q == 2:
                d2 -= 2 * e
        for p, e in factor(n).items():
            if e >= 2:
                defc[p] = defc.get(p, 0) + (e - 1)
                touch(p)
                if p == 2:
                    d2 += e - 1
            for q, f in p1_factors(p):
                defc[q] = defc.get(q, 0) + f
                touch(q)
                if q == 2:
                    d2 += f
        integral_flag = not pos
        if n <= 300:
            if exact_integral(n) != integral_flag:
                print(f"SELF-CHECK MISMATCH at n={n}")
                sys.exit(2)
        in_set = n in SET
        if integral_flag and not in_set:
            viol_set.append(n)
        if (not in_set) and n >= 35 and d2 < 1:
            viol_d2.append((n, d2))
        if n >= 35 and d2 < d2_min:
            d2_min, d2_min_at = d2, n
        if n % 1_000_000 == 0:
            line = json.dumps({"n": n, "d2": d2, "pos_q": len(pos),
                               "viol_set": len(viol_set), "viol_d2": len(viol_d2),
                               "elapsed_s": round(time.time() - t0, 1)})
            prog.write(line + "\n"); prog.flush()
            print(line, flush=True)

result = {"N": N, "self_check_exact_through": 300,
          "violations_integrality_set": viol_set[:100],
          "violations_d2_ge1": viol_d2[:100],
          "n_violations_set": len(viol_set), "n_violations_d2": len(viol_d2),
          "d2_min_ge35": d2_min, "d2_min_at": d2_min_at,
          "elapsed_s": round(time.time() - t0, 1)}
with open(f"{OUT}/verify_result.json", "w") as f:
    json.dump(result, f, indent=1)
print(json.dumps(result, indent=1))
